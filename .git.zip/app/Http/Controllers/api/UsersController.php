<?php

namespace App\Http\Controllers\api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\Models\Pdf;
use Illuminate\Support\Facades\Storage;

class UsersController extends Controller
{
    public function update_file() {
         $current_photo_path = public_path('images/flags/') . $current_photo;
           if (file_exists($current_photo_path)) {
                @unlink($current_photo_path);
            }
    }
    
    public function completedpdfFiletoserver(Request $request) {
         request()->validate(['name' => 'required', 'pdf' => 'required', 'user_id' => 'required']);
         $pdf = Pdf::where('name' , request()->name)->first();
         $current_pdf = $pdf->name;
         $current_pdf_path = public_path('storage/') . $current_pdf;
         if (file_exists($current_pdf_path)) {
                @unlink($current_pdf_path);
         }
          $file = $request->get('pdf');
          $base = base64_decode($file);
          $fileName = $pdf->name;
          Storage::disk('local')->put($fileName, $base);
          $pdf->status = 1;
          $pdf->save();
          
          return response()->json(['message' => 'success']);
         
         
    }
}
